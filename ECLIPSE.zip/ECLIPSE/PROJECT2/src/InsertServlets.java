

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/InsertServlets")
public class InsertServlets extends HttpServlet {
	
	
	private static final long serialVersionUID = 1L;

    public InsertServlets() {
       
    }
 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		System.out.println("HIII");
		int id=Integer.parseInt(request.getParameter("id"));
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String city=request.getParameter("city");
		People p=new People();
		p.setId(id);
		p.setFname(fname);
		p.setLname(lname);
		p.setCity(city);
		
		MainPage mp= new MainPage();
		int i=mp.insert(p);

			
		if(i>0)
		{
				out.println("<p>RECORD SAVED SUCCESSFULLY!!!</p>");
				RequestDispatcher rd=request.getRequestDispatcher("form.html");
				rd.include(request, response);
			}
		
		else{
				out.println("SORRY UNABLE TO SAVE RECORD");
			}
		out.close();
			
		}
		
	}



