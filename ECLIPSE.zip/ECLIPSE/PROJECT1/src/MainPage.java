import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class MainPage {

	static int status = 0;
	static Connection conn=null;
	static PreparedStatement ps;
	
	public static Connection getConnection(){
		  try{
	        	Class.forName("oracle.jdbc.driver.OracleDriver");
	        	conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
	        	if(conn!=null)
	   				System.out.println("\nCONNECTION ESTABLISHED...............................");
      	}
      	catch(Exception e){
      		e.printStackTrace();
      	}
		return conn;
	}
	
	
	public int insert(People p){
	             try {
	            	 conn=MainPage.getConnection();
					 ps=conn.prepareStatement("insert into peopleclub1(id,fname,lname,city) values(?,?,?,?)");
					 ps.setInt(1,p.getId());
		             ps.setString(2, p.getFname());
		             ps.setString(3, p.getLname());
		             ps.setString(4, p.getCity());
		             status=ps.executeUpdate();
		             conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
	            
        return status;
       
	}
	
	public static int delete(int id){
		 try {
        	 conn=MainPage.getConnection();
			 ps=conn.prepareStatement("delete from peopleclub1 where id=?");
			 ps.setInt(1,id);
             status=ps.executeUpdate();
             conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return status; 
	}
	
	public static List<People> view(int id){
		List<People> people=new ArrayList<People>();  
		People p=new People();
		 try {
       	 conn=MainPage.getConnection();
       	   
			 ps=conn.prepareStatement("select * from peopleclub1 where id=?");
			 ps.setInt(1,id);
			 ResultSet rs=ps.executeQuery();
			 if(rs.next()){
				 p.setId(rs.getInt(1));
				 p.setFname(rs.getString(2));
				 p.setLname(rs.getString(3));
				 p.setCity(rs.getString(4));
			 }
			 people.add(p);
            conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return people;
       
	}
}




