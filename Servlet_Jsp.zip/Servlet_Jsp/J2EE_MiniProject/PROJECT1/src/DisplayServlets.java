

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DisplayServlets")
public class DisplayServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DisplayServlets() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<People> list = new ArrayList<People>();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		list=MainPage.view(id);
		Iterator<People> itr2=list.iterator();
		while(itr2.hasNext()){
			
			People e1 = itr2.next();
			out.print(e1.getId()+" ");
			out.print(e1.getFname()+" ");
			out.print(e1.getLname()+" ");
			out.print(e1.getCity()+" ");
			
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
