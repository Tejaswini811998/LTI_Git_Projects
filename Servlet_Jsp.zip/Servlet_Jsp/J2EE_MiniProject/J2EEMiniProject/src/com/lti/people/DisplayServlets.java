package com.lti.people;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/DisplayServlets")
public class DisplayServlets extends HttpServlet {
	
	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
	Connection con=null;
	private static final long serialVersionUID = 1L;

    public DisplayServlets() {
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
	
		try{
			Connection con=PeopleDao.getConnection();
		}catch(Exception e){
			
		}
		
		/*String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String date=request.getParameter("dob");
		String city=request.getParameter("city");
		People p=new People();
		p.setId(id);
		p.setFname(fname);
		p.setLname(lname);
		p.setDate(date);
		p.setCity(city);
		int status = 0;
		try{
			 con=DriverManager.getConnection(URL, user, pass);
			
			if(con!=null){
				System.out.println("\nCONNECTION ESTABLISHED...............................");
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		
			try{
				Connection con=PeopleDao.getConnection();
				PreparedStatement ps=con.prepareStatement("insert into peopleclub(id,fname,lname,dob,city) values(?,?,?,?,?)");
				ps.setInt(1,p.getId());
				ps.setString(2, p.getFname());
				ps.setString(3, p.getLname());
				ps.setString(4, p.getDate());
				ps.setString(5, p.getCity());
				status=ps.executeUpdate();
				con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			if(status>0)
			{
				out.println("<p>RECORD SAVED SUCCESSFULLY!!!</p>");
				RequestDispatcher rd=request.getRequestDispatcher("index.html");
				rd.include(request, response);
			}
		
		else{
				out.println("SORRY UNABLE TO SAVE RECORD");
			}
		out.close();
			
		}*/
		
	}}


