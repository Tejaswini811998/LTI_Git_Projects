package com.lti.people;
import com.lti.people.People;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PeopleDao {

	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
	
	public static Connection getConnection() throws SQLException{
		
		Connection con=null;
		try{
			 con=DriverManager.getConnection(URL, user, pass);
			
			if(con!=null){
				System.out.println("\nCONNECTION ESTABLISHED...............................");
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		return con;
		
	}
	
	//INSERT METHOD-----------
	public static int insert(People p){
		String sql;
	int status=0;
	sql="insert into peopleclub1(id,fname,lname,city) values(?,?,?,?)";
	try{
		Connection con=PeopleDao.getConnection();
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,p.getId());
		ps.setString(2, p.getFname());
		ps.setString(3, p.getLname());
		ps.setString(4, p.getCity());
		status=ps.executeUpdate();
		con.close();
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return status;
		}
	
	
}
