package com.lti.services;

import java.sql.SQLException;
import java.util.List;

import com.lti.bean.Customer;
import com.lti.dao.CustomerDao;
import com.lti.dao.CustomerDaoImpl;


public class CustomerServiceImpl implements CustomerService {
	
		CustomerDao dao;
		List<Customer> myList;
	
		public CustomerServiceImpl() throws SQLException 
	{
		dao=  new CustomerDaoImpl();
	}
		@Override
		public List<Customer> getAllCustomers()
	{
		try 
			{
			myList = dao.getAllCustomers();
			System.out.println(myList);
			return myList;
			}
		catch (SQLException e)
			{
			e.getMessage();
			}
		return myList;			
	}
}
