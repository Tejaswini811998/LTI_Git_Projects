package com.lti.servlets;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>REGISTERED USER DETAILS.....</h1><br>");
		String name=request.getParameter("txtName");
		String empCode=request.getParameter("empcode");
		String dept=request.getParameter("dept");
		String day=request.getParameter("day");
		String mon=request.getParameter("month");
		String year=request.getParameter("year");
		String addr=request.getParameter("addr");
		String[] trainings = request.getParameterValues("names");
		String trainingPrgm=request.getParameter("attend");
		
		
		out.println(
				"<table>"
				+ "<tr>"+"<td> NAME:</td><td>"+name+"</td></tr>"
				+"<tr>"+"<td> Employee Code:</td><td>"+empCode+"</td></tr>"
				+"<tr>"+"<td> Department name:</td><td>"+dept+"</td></tr>"	
				+"<tr>"+"<td> DATE OF JOINING:</td><td>"+day+"/"+mon+"/"+year+"</td></tr>"
				+"<tr>"+"<td> Address:</td><td>"+addr+"</td></tr>"
				+"<tr>"+"<td> Training Programs:</td><td>"+trainingPrgm+"</td></tr>"
				+"</table>");
		out.println("<tr>"+"<td>Trainings Attended </td>");
		for(String t : trainings){
		out.println("<tr><td>"+t+"</td></tr>");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
	}

}
