package com.lti.rest;

import java.time.LocalDate;
import java.util.List;

public class PnrDetails {
    private long pnrNo;
    private int trainNo;
    private LocalDate travelDate;
    private List<Passenger> passengers;
    public long getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(long pnrNo) {
		this.pnrNo = pnrNo;
	}

	public int getTrainNo() {
		return trainNo;
	}

	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}

	public LocalDate getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(LocalDate travelDate) {
		this.travelDate = travelDate;
	}

	public List<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

	@Override
	public String toString() {
		return "PnrDetails [pnrNo=" + pnrNo + ", trainNo=" + trainNo + ", travelDate=" + travelDate + ", passengers="
				+ passengers + "]";
	}

	
 
}
