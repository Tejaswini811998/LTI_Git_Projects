package com.lti.rest;

public class Passenger {
	private String pName;
	private int pAge;
	private Gender gender;
	private Status status;
	
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpAge() {
		return pAge;
	}
	public void setpAge(int pAge) {
		this.pAge = pAge;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	
	public static enum Gender{
		MALE,FEMALE,OTHERS;
	}
	public static enum Status{
		RAC,WAITING,CONFIRMED;
	}
	@Override
	public String toString() {
		return "Passenger [pName=" + pName + ", pAge=" + pAge + ", gender=" + gender + ", status=" + status + "]";
	}
	
	
}
