package com.lti.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.lti.config.AppConfig;
import com.lti.model.Student;
import com.lti.service.StudentService;

public class Main {

	public static void main(String[] args) {
		ApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);
		Student student=appContext.getBean("student",Student.class);
		
		student.setRollNumber(12);
		student.setStudentName("RAM");
		student.setStudentScore(100.00);
		student.getAddress().setAddressId(10);
		student.getAddress().setCity("Thane");
		student.getAddress().setPin("400345");
		//System.out.println(student.getAddress());
		
		StudentService service=appContext.getBean("service", StudentService.class);
		boolean result=service.addStudent(student);
		if(result)
		{
			System.out.println("Student is Added");
			Student student2=service.findStudentByRollNumber(12);
			System.out.println(student2);
			System.out.println(student2.getAddress());
		}else{
			System.out.println("Student is not added");
		}
		
		Student s1=appContext.getBean("student",Student.class);
		s1.getAddress().setAddressId(120);
	s1.getAddress().setCity("Mumbai");
		s1.getAddress().setPin("400345");
    result=service.addStudent(s1);
		System.out.println(s1.getAddress());
	    Student s2=service.findStudentByRollNumber(12);

		System.out.println(s2.getAddress());
		
	}

}
