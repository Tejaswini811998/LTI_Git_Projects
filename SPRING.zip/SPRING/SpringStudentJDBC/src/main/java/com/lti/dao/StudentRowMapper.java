package com.lti.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.lti.model.Student;
import com.lti.ui.Main2;

public class StudentRowMapper implements RowMapper<Student>{

	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		int rollNumber=rs.getInt("rollnumber");
		String studentName=rs.getString("student_name");
		double studentScore=rs.getDouble("student_score");
		
		Student student=Main2.getContext().getBean("student",Student.class);
		student.setRollNumber(rollNumber);
		student.setStudentName(studentName);
		student.setStudentScore(studentScore);
		return student;
	}	
}
