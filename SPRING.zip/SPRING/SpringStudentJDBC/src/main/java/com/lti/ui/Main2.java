package com.lti.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.model.Student;
import com.lti.service.StudentService;
import com.lti.service.StudentServiceImpl;

public class Main2 {

	private static ApplicationContext context;
	
	public static ApplicationContext getContext() {
		return context;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean flag=true;
		context=new ClassPathXmlApplicationContext("spring-config.xml");
		StudentService service=context.getBean("service", StudentServiceImpl.class);
		
		do{
		System.out.println("1. Add Student");
		System.out.println("2. Find Student");
		System.out.println("3. Modify Student");
		System.out.println("4.Delete Student");
		System.out.println("0.Exit Application");
		System.out.println("Please Enter your choice: ");
		int choice=sc.nextInt();
		
		switch(choice){
			case 1:
				System.out.println("Enter student RollNumber:");
				int rollNumber=sc.nextInt();
				System.out.println("Enter Student Name:");
				String studentName=sc.next();
				System.out.println("Enter student Score");
				double studentScore=sc.nextDouble();
				Student student=context.getBean("student",Student.class);
				student.setRollNumber(rollNumber);
				student.setStudentName(studentName);
				student.setStudentScore(studentScore);
				boolean result=service.addStudent(student);
				if(result){
					System.out.println("Student with Roll Number:"+student.getRollNumber()+" Added in Database Successfully !!!!!!.....");
				}
				else{
					System.out.println("Sorry Student Record Could Not be Added-----Try Again");
				}
				break;
			
			case 2:
				System.out.println("Enter Student RollNumber:");
				rollNumber=sc.nextInt();
				student = service.findStudentByRollNumber(rollNumber);
				System.out.println(student);
				break;
			
			case 3:
				break;
		
			case 4:
				break;
			
			case 0:
				flag=false;
			} 
		}while(flag);
		System.out.println("Successfully Exited");
			

	
	}

	
}
