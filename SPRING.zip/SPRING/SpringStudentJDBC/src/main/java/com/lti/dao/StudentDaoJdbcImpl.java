package com.lti.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.lti.model.Student;

public class StudentDaoJdbcImpl implements StudentDao {

	private JdbcTemplate jdbcTemplate;
	private static final String CREATE_STUDENT="insert into student(rollnumber,student_name,student_score) values(?,?,?)";
	private static final String READ_STUDENT="select * from student where rollnumber=?";
	
	@Override
	public int createStudent(Student student) {
	int result=jdbcTemplate.update(CREATE_STUDENT,student.getRollNumber(),student.getStudentName(),student.getStudentScore());
		return result;
	}

	@Override
	public Student readStudentByRollNumber(int rollNumber) {
		//List<Students> students=jdbcTemplate.query(READ_STUDENT,new StudentRowMapper() );
		Student result=jdbcTemplate.queryForObject(READ_STUDENT, new Object[]{rollNumber},new StudentRowMapper());//either u get one record or no record so we use this.....
		return result;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
	
}
