package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication //should be 

public class Main {
	public static void main(String[] args) {
		
		SpringApplication.run(Main.class, args);	//return type of run method is configurable application context
		//OR
		//Application context=SpringApplication.run(Main.class, args);
		
	}

}
