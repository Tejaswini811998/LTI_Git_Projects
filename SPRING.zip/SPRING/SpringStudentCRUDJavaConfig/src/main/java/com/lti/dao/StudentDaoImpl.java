package com.lti.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	public StudentDaoImpl() {
	students=new ArrayList<>();
	}

	private static List<Student> students; //IN MEMORY DATABASE
	
	@Override
	public int createStudent(Student student) {
	
		boolean result=students.add(student);
		if(result)
		return 1;
		else
		return 0;
	}

	@Override
	public Student readStudentByRollNumber(int rollNumber) {
		for(Student s:students){
			if(s.getRollNumber()==rollNumber){
				return s;
			}
		}
		return null;
	}

	
}
