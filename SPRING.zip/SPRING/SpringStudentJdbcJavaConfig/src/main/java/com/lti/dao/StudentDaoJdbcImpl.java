package com.lti.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.lti.model.Student;
@Repository
public class StudentDaoJdbcImpl implements StudentDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private static final String CREATE_STUDENT="insert into student(rollnumber,student_name,student_score) values(?,?,?)";
	private static final String READ_STUDENT="select * from student where rollnumber=?";
	private static final String UPDATE_STUDENT="update student set student_name=?,student_score=? where rollnumber=?";
	private static final String DELETE_STUDENT="delete from student where rollnumber=?";
	private static final String VIEW_STUDENT="select * from student";
	
	@Override
	public int createStudent(Student student) {
	int result=jdbcTemplate.update(CREATE_STUDENT,student.getRollNumber(),student.getStudentName(),student.getStudentScore());
		return result;
	}

	@Override
	public Student readStudentByRollNumber(int rollNumber) {
		//List<Students> students=jdbcTemplate.query(READ_STUDENT,new StudentRowMapper() );
		Student result=jdbcTemplate.queryForObject(READ_STUDENT, new Object[]{rollNumber},new StudentRowMapper());//either u get one record or no record so we use this.....
		return result;
	}
	
	@Override
	public int updateStudent(Student student) {
		int result=jdbcTemplate.update(UPDATE_STUDENT,student.getStudentName(),student.getStudentScore(),student.getRollNumber());
		return result;
	}
	
	@Override
	public int deleteStudent(int rollNumber) {
		int result=jdbcTemplate.update(DELETE_STUDENT,rollNumber);
		return result;
	}

	@Override
	public List<Student> viewAllStudent() {		
		return jdbcTemplate.query(VIEW_STUDENT,new StudentRowMapper() );
		
	}

	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
}
