package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.model.Student;
import com.lti.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService service;
	
	
	@RequestMapping(path="/",method=RequestMethod.GET)
	public String homePage(){
		return "index";
	}
	
	@RequestMapping(path="addStudent.view",method=RequestMethod.GET)
	public String addStudentView(){
		return "addStudent";
	}
	
	@RequestMapping(path="addStudent.do",method=RequestMethod.POST)
	public String addStudent(Student student){
		
		/*String rollNumber=request.getParameter("rollNumber"); No need to do this manually
		 * no need to fetch value manually
		 * no need to create object manually
		String studentName=request.getParameter("studentName");
		String studentScore=request.getParameter("studentScore");*/
		
		boolean result=service.addStudent(student);
		if(result){
			return "redirect:viewAllStudent.do";//to redirect to call another controller and not page
		}else
		{
			return "error";
		}
	}
	
	/*
	@RequestMapping(path="addStudent.do",method=RequestMethod.POST)
	public String addStudent(@RequestParam("rollNumber") int rollNumber,
							 @RequestParam("studentName") String studentName,
							 @RequestParam("studentScore") double studentScore){
		
		Student student=context.getBean("Student.class");
		student.setParameter("rollNumber");
		student.setParameter("studentName");
		student.setParameter("studentScore");
		
		
		
		boolean result=service.addStudent(student);
		if(result){
			return "redirect:viewAllStudent.do";//to redirect to call another controller and not page
		}else
		{
			return "error";
		}
	}
	*/	@RequestMapping(path="viewAllStudent.do")
		public String viewAllStudent(Model model){
			List<Student> student=service.viewStudentDetails();
			model.addAttribute("students", student);
			return "viewAllStudent";
	
		
	}
		@RequestMapping(path="deleteStudent.view",method=RequestMethod.GET)
		public String deleteStudentView(){
			return "deleteStudent";
		}
		
		@RequestMapping(path="deleteStudent.do",method=RequestMethod.GET)
		public String deleteStudentStudent(int rollNumber){
			
			boolean result=service.deleteStudentDetails(rollNumber);
			if(result){
				return "redirect:viewAllStudent.do";
			}else
			{
				return "error";
			}
		}
		@RequestMapping(path="findStudentByRollNo.view")
		public String studentDetailview(){
			return "findStudentByRollNo";
		}
		
		
		@RequestMapping(path="findStudentByRollNo.do",method=RequestMethod.GET)
		public String viewStudentDetails(int rollNumber,Model model){
			
			Student student=service.findStudentByRollNumber(rollNumber);
			model.addAttribute("student",student);
			return "viewStudent";
			
		}
		
		
		@RequestMapping(path="updateStudent.view",method=RequestMethod.GET)
		public String updateStudentView(){
			return "updateStudent";
		}
		
		@RequestMapping(path="updateStudent.do",method=RequestMethod.GET)
		public String updateStudent(Student student){
			
				/*String rollNumber=request.getParameter("rollNumber"); No need to do this manually
			 * no need to fetch value manually
			 * no need to create object manually
			String studentName=request.getParameter("studentName");
			String studentScore=request.getParameter("studentScore");*/
			
			boolean result=service.updateStudentDetails(student);
			if(result){
				return "redirect:viewAllStudent.do";//to redirect to call another controller and not page
			}else
			{
				return "error";
			}
		}
}
