package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication //equivalent to 3 configurations..........
//from this component scaning in done from package where main class is present
//in the packages it search for this @component, @repository, @service ,@bean and registered in application context
public class Main {
	public static void main(String[] args) {
		
		SpringApplication.run(Main.class, args);//finds a class which has @SpringBootApplication annotation and run main.class which has this annotation
		//return type of run method is configurable Applicationcontext
		//OR
		//ApplicationContext context=SpringApplication.run(Main.class, args);
		
		
		//TO DEAL WITH CORS ERROR JUST RUN THE SERVER i.e MAIN ONCE THEN also cors error not removed we need to include something.....
		//since request send by another app and server need to approve request so we get cors error
		//so we need to include one annotation to remove cors error
		//first stop service and include @CrossOrigin annotation to solve isssue of cors(cross origin resource service)...
	}

}
