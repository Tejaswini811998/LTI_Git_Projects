package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Student;
@Repository
public class StudentDaoImpl implements StudentDao {
	
	@PersistenceContext
	private EntityManager entityManager;//persistence is responsible for getting entity manager through
	public StudentDaoImpl(){
		
	}
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int createStudent(Student student) {
		entityManager.persist(student);
		return 1;
	}
	@Override
	public Student readStudentByRollNumber(int rollNumber) {
		return entityManager.find(Student.class, rollNumber);
	}
	@Override
	public List<Student> readAllStudents() {
		String jpql = "From Student";
		TypedQuery<Student> tquery = entityManager.createQuery(jpql, Student.class);
		return tquery.getResultList();
	}
	

	@Override
	@Transactional
	public int updateStudent(Student student) {
		String jpql="Update Student s set s.studentName=:student_name,s.studentScore=:student_score where s.rollNumber=:roll_number ";
		Query tquery = entityManager.createQuery(jpql);
		tquery.setParameter("roll_number", student.getRollNumber());
		tquery.setParameter("student_name", student.getStudentName());
		tquery.setParameter("student_score", student.getStudentScore());
		int result=tquery.executeUpdate();
		return result;
	}
	@Override
	@Transactional
	public int deleteStudent(int rollNumber){
		String jpql="delete from Student where rollNumber= :roll_number";
		Query tquery = entityManager.createQuery(jpql);
		tquery.setParameter("roll_number", rollNumber);
		int result=tquery.executeUpdate();
		return result;
		
	}
}
