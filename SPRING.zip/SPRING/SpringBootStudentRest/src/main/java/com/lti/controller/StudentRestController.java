package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Student;
import com.lti.service.StudentService;

@RestController
@RequestMapping(path="students")
@CrossOrigin
public class StudentRestController {

	@Autowired
	private StudentService service;
	
	//http://localhost:9090/students
	@RequestMapping(method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Student> findAllStudents(){
		List<Student> students=service.findAllStudents();
		return students;
	}
	
	//http://localhost:9090/students/425
	@RequestMapping(path="{rollNo}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE) //path variable name can be anything
	public Student findStudentByRollNumber(@PathVariable("rollNo") int rollNumber){
		Student students = service.findStudentByRollNumber(rollNumber);
		
		return students;
	}
	
	//http://localhost:9090/students
	@RequestMapping(method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE) //path variable name can be anything
	public void addStudent(@RequestBody Student student){
		service.addStudent(student);
	
	}
	
	//http://localhost:9090/students
		@RequestMapping(path="update",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE) //path variable name can be anything
		public void updateStudent(@RequestBody Student student){
		
			
			service.updateStudentDetails(student);
		
		}
		
		
		@RequestMapping(path="delete/{rollNo}",method=RequestMethod.GET)
		public void deleteStudent(@PathVariable("rollNo") int rollNumber){
			boolean b = service.deleteStudentDetails(rollNumber);
			
			

		}
}
