package com.lti.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.lti.model.Student;

@Configuration
@ComponentScan(basePackages="com.lti")
public class AppConfig {

	
	
}
