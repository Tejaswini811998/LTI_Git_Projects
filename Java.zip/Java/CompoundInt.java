import java.util.*;
import java.lang.*;
import java.io.*;
class CompoundInt
{
static void comp_int(double p,double r,double n){
double amount,comp;
amount=p*(Math.pow(1+(r/100),n));
comp=amount-p;
System.out.println("Compound Interest is:"+comp);
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
double principal,rate,no_years;
System.out.println("Enter principal,rate of Interest,Time in years");
principal=sc.nextDouble();
rate=sc.nextDouble();
no_years=sc.nextDouble();
comp_int(principal,rate,no_years);

}
}