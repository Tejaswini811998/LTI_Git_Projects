import java.util.*;
class Array1
{
public static void main(String args[])
{
int i;
Scanner sc=new Scanner(System.in);
      int []marks=new int[5];

System.out.println("Enter the array elements:");
     for(i=0;i<marks.length;i++)
        {
         marks[i]=sc.nextInt();
         }

System.out.println("Values in array are:");
for(int m:marks){
        System.out.println(m);
              }
}
}