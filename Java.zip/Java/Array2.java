import java.util.*;
class Array2
{
public static void main(String args[])
{
Scanner sc = new Scanner(System.in);
int count = 0;

System.out.println("Enter the size of array");
int n=sc.nextInt();
char[] c = new char[n];
System.out.println("Enter the characters");
for(int i=0;i<n;i++)
{
c[i]= sc.next().charAt(0);
} 

for(int i=0;i<n;i++)
{
  if(c[i]=='a' || c[i]=='e' || c[i]=='i' ||c[i]=='o' ||c[i]=='u' ||c[i]=='A' ||c[i]=='E' ||c[i]=='I' ||c[i]=='O' ||c[i]=='U')
	{System.out.println("Vowel is "+c[i]);
    count++;}
}
System.out.println("Number of Vowel in character Array is "+count);


}
}