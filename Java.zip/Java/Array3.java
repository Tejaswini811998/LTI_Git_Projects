import java.util.*;
class Array3
{
public static void main(String args[])
{
Scanner sc = new Scanner(System.in);
int count = 0;

System.out.println("Enter the size of array");
int n=sc.nextInt();
char[] ch = new char[n];
System.out.println("Enter the characters");
for(int i=0;i<n;i++)
{
ch[i]= sc.next().charAt(0);
} 

for(char c:ch){
switch(c){
          case 'A':
          case 'E':
          case 'I':
          case 'O':
          case 'U':
          case 'a':
          case 'e':
          case 'i':
          case 'o':
          case 'u':
          count++;
          break;
    }
}
System.out.println("Number of vowels is:"+count);
}
}