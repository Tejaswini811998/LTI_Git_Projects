package com.lti.bank;

public class MainClass {

	public static void main(String[] args) {

		Bank bank=new ICICIBank();
		bank.withdraw();
		
		Bank bank1=new HDFCBank();
		bank1.withdraw();
	}

}
