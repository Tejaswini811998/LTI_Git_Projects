package com.lti.bank;

public class HDFCBank implements Bank {

	@Override
	public void withdraw() {
		System.out.println("Withdrawing from HDFC bank");
	}

	@Override
	public void deposit() {
		System.out.println("Depositing to HDFC bank");
	}

	@Override
	public void fundTransfer() {

	}

	@Override
	public void openAccount() {

	}

}
