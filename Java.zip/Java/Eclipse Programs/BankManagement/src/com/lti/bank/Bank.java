package com.lti.bank;

public interface Bank {

	void withdraw();
	void deposit();
	void fundTransfer();
	void openAccount();
}
