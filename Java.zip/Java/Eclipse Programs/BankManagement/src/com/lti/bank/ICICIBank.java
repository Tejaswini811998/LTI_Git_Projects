package com.lti.bank;

public class ICICIBank implements Bank {

	@Override
	public void withdraw() {
		System.out.println("Withdrawing from ICICI bank");
	}

	@Override
	public void deposit() {
		
		System.out.println("Depositing to ICICI bank");
	}

	@Override
	public void fundTransfer() {

	}

	@Override
	public void openAccount() {

	}

}
