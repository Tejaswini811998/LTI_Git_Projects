
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MainPage2 {

	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
	
	
	
	public static void main(String[] args) {
		
		Connection conn=null;
		
		try {
			 conn=DriverManager.getConnection(URL, user, pass);
			
			if(conn!=null){
				System.out.println("\nCONNECTION ESTABLISHED...............................");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int c;
		do{
		System.out.println();
		System.out.println("\n***********************WELCOME TO EMPLOYEE MANAGEMENT PORTAL*********************\n\n\n");
		System.out.println("----PLEASE SELECT AN OPERATION--------\n\n");
		System.out.println("1. ADD AN EMPLOYEE-->\n");
		System.out.println("2. UPDATE AN EMPLOYEE-->\n");
		System.out.println("3. DELETE AN EMPLOYEE-->\n");
		System.out.println("4. SEARCH AN EMPLOYEE-->\n");;
		System.out.println("5. VIEW ALL EMPLOYEE-->\n");
		System.out.println("6. EXIT-->\n");
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("\nENTER YOUR CHOICE:------");
		int ch=sc.nextInt();
		
		switch(ch){
		case 1:
			System.out.println("Enter name,salary,designation");
			String name=sc.next();
			int sal=sc.nextInt();
			String des=sc.next();
			
			String sql="insert into emp(psno,name,salary,designation) values(SEQ_ID5.nextval,?,?,?)";
			try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setInt(2, sal);
			ps.setString(3, des);
			int i=ps.executeUpdate();
			if(i>0)
			System.out.println("EMPLOYEE ADDED!!!!!");
			else
				System.out.println("Employee could not be Added");}
			catch(SQLException e){
				e.printStackTrace();
			}
			
			break;
			
		case 2:
			
			System.out.println("EMPLOYEE UPDATED");
			
		case 3:
			try{
				System.out.println("Enter Employee PSNO for deletion:");
				int psno=sc.nextInt();
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery("delete from emp where psno="+psno);
				
				
				/*while(rs.next()){
					System.out.println("\n"+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+" "+rs.getString(4));
				}*/
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			System.out.println("EMPLOYEE DELETED!!!!!");
			break;
		case 4:
			try{
				System.out.println("Enter Employee PSNO:");
				int psno=sc.nextInt();
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery("select * from emp where psno="+psno);
				
				
				while(rs.next()){
					System.out.println("\n"+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+" "+rs.getString(4));
				}
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			System.out.println("EMPLOYEE FOUND!!!!!");
			break;
		case 5:
			System.out.println(" VIEW ALL EMPLOYEES!!!!!");
			try{
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from emp");
			
			
			while(rs.next()){
				System.out.println("\n"+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+" "+rs.getString(4));
			}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			break;
			default:
			System.out.println("EXIT!!!!!");
			break;
		}
		System.out.println("Do you want to Continue??[1/0]");
		c=sc.nextInt();
		
		
		}while(c==1);
		
		
	}

	
	
}
