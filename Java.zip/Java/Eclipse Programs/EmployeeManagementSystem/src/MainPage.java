import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MainPage {

	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
	
	
	
	public static void main(String[] args) {
		
		Statement st;
		Connection conn=null;
		String sql;
		int c;
		try {
			 conn=DriverManager.getConnection(URL, user, pass);
			
			if(conn!=null){
				System.out.println("\nCONNECTION ESTABLISHED...............................");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println();
		System.out.println("\n***********************WELCOME TO EMPLOYEE MANAGEMENT PORTAL*********************\n\n\n");
		do{
		
		System.out.println("\n----PLEASE SELECT AN OPERATION--------\n\n");
		System.out.println("1. ADD AN EMPLOYEE-->\n");
		System.out.println("2. UPDATE AN EMPLOYEE-->\n");
		System.out.println("3. DELETE AN EMPLOYEE-->\n");
		System.out.println("4. SEARCH AN EMPLOYEE-->\n");;
		System.out.println("5. VIEW ALL EMPLOYEE-->\n");
		System.out.println("6. EXIT-->\n");
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("\nENTER YOUR CHOICE:------");
		int ch=sc.nextInt();
		
		switch(ch){
		case 1:
			System.out.println("Enter name,salary,designation");
			String name=sc.next();
			int sal=sc.nextInt();
			String des=sc.next();
			
			sql="insert into emp(psno,name,salary,designation) values(SEQ_ID5.nextval,?,?,?)";
			try{
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setInt(2, sal);
			ps.setString(3, des);
			int i=ps.executeUpdate();
			if(i>0)
			System.out.println("EMPLOYEE ADDED!!!!!");
			else
				System.out.println("Employee could not be Added");}
			catch(SQLException e){
				e.printStackTrace();
			}
			
			break;
			
		case 2:
			try{
				System.out.println("Enter field to be updated:\n 1.NAME \n 2.SALARY \n 3.DESIGNATION");
				int field=sc.nextInt();
				switch(field){
				case 1: 
					   System.out.println("Enter Employee PSNO:");
					   int psno=sc.nextInt();
					   System.out.println("Enter Name to be Updated");
					   String name1=sc.next();
					   st=conn.createStatement();
					   sql="update emp set name=? where psno="+psno;
						try{
						PreparedStatement ps=conn.prepareStatement(sql);
						ps.setString(1, name1);
						int i=ps.executeUpdate();
						if(i>0)
						System.out.println("EMPLOYEE NAME UPDATED!!!!!");
						else
							System.out.println("Employee could not be Added");
						}
						
						catch(SQLException e){
							e.printStackTrace();
						}
				break;//UPDATION OF NAME COMPLETE
				
				
				case 2:
					System.out.println("Enter Employee PSNO:");
				    int psno1=sc.nextInt();
				   System.out.println("Enter Salary to be Updated");
				   double sal1=sc.nextInt();
				   st=conn.createStatement();
				   sql="update emp set salary=? where psno="+psno1;
					try{
					PreparedStatement ps=conn.prepareStatement(sql);
					ps.setDouble(1, sal1);
					int i=ps.executeUpdate();
					if(i>0)
					System.out.println("EMPLOYEE SALARY UPDATED!!!!!");
					else
						System.out.println("Employee could not be Added");
					}
					catch(SQLException e){
						e.printStackTrace();
					}
			break;//UPDATION OF SALARY COMPLETE
			
			
		case 3:
		   System.out.println("Enter Employee PSNO:");
		   int ps=sc.nextInt();
		   System.out.println("Enter Designation to be Updated");
		   String des1=sc.next();
		   st=conn.createStatement();
		   sql="update emp set designation=? where psno="+ps;
			try{
			PreparedStatement ps1=conn.prepareStatement(sql);
			ps1.setString(1, des1);
			int i=ps1.executeUpdate();
			if(i>0)
			System.out.println("EMPLOYEE DESIGNATION UPDATED!!!!!");
			
			else
				System.out.println("Employee could not be Added");
			}
			catch(SQLException e){
				e.printStackTrace();
			}
	        break;//UPDATION OF DESIGNATION COMPLETE
	
	
	default:System.out.println("PLEASE ENTER VALID CHOICE----");
		    break;
				}}
				catch(Exception e){
					e.printStackTrace();
				}
			System.out.println("EMPLOYEE DATA UPDATED!!!!!");
			break;
		case 3:
			try{
				System.out.println("Enter Employee PSNO for deletion:");
				int ps=sc.nextInt();
				st=conn.createStatement();
				st.executeQuery("delete from emp where psno="+ps);
				System.out.println("Record Deleted");
				
				
				/*while(rs.next()){
					System.out.println("\n"+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+" "+rs.getString(4));
				}*/
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			System.out.println("EMPLOYEE DELETED!!!!!");
			break;
		case 4:
			try{
				System.out.println("Enter Employee PSNO:");
				int ps=sc.nextInt();
				st=conn.createStatement();
				ResultSet rs=st.executeQuery("select * from emp where psno="+ps);
				
				
				while(rs.next()){
					System.out.println("\n"+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+" "+rs.getString(4));
				}
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			System.out.println("EMPLOYEE FOUND!!!!!");
			break;
		case 5:
			System.out.println(" VIEW ALL EMPLOYEES!!!!!");
			try{
			st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from emp");
			
			
			while(rs.next()){
				System.out.println("\n"+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+" "+rs.getString(4));
			}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			break;
			
			
			default:
			System.out.println("EXIT!!!!!");
			System.exit(0);
			break;
		}
		
		System.out.println("Do you want to Continue??[1/0]");
		c=sc.nextInt();
		
		
		}while(c==1);
		
		
	}

	
	
}
