import java.util.Scanner;

public class SeatMap {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the rows and columns ");
		int x = sc.nextInt();
		int y = sc.nextInt();
		int [][]seats=new int[x][y];
		int r = 65;
		//int c=1;
		
		System.out.print(" ");
		for(int i=1;i<=y;i++)
		System.out.print(" "+i);
		
		System.out.println();
		for(int i=0;i<x;i++){
			System.out.print((char)r+" ");
			for(int j=0;j<y;j++){
				System.out.print(seats[i][j]+" ");
			}
			System.out.println();
			r++;
			}
	}

}
