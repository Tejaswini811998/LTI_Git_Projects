import java.util.Scanner;

public class TwoDMain {

	public static void main(String[] args) {
		//Array Initialization
		System.out.println("Enter the number of rows and columns");
		Scanner sc=new Scanner(System.in);
		int r=sc.nextInt();
		int c=sc.nextInt();
		char [][] seats=new char[r][c];
		System.out.println("Enter "+(r*c)+" values");
		for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			seats[i][j]=sc.next().charAt(0);
		}
		}
		System.out.println("Two D Array values are:");
		for(int i=0;i<r;i++){
			for(int j=0;j<c;j++){
				System.out.print(seats[i][j]+" ");
			}
			System.out.println();
			}
        
	}

}
