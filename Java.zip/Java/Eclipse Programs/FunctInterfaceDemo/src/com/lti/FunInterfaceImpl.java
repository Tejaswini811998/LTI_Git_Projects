package com.lti;

public class FunInterfaceImpl implements FunInterface {

	@Override
	public void fun1() {
		// TODO Auto-generated method stub

	}


}
