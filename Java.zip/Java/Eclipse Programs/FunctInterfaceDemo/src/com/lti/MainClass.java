package com.lti;

public class MainClass {

	public static void main(String[] args) {
		
		Employee emp1=new Employee("1001", "David", 23, 20000);
		System.out.println(emp1);
		
		FunInterfaceImpl obj = new FunInterfaceImpl();
		obj.add(10, 20);

	}

}
