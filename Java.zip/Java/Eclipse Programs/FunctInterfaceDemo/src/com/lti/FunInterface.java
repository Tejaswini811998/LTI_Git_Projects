package com.lti;
@FunctionalInterface
public interface FunInterface {
	void fun1();
	String toString();
	boolean equals(Object obj);
	
	default void add(int num1,int num2)
	{
		System.out.println(num1+num2);
	}
	default void sub(int num1,int num2)
	{
		System.out.println(num1-num2);
	}
	
}
