class A
{
	void yes()
	{
		System.out.println("Parent class");
	}
}
class B extends A
{
	void yes()
	{   
		super.yes();
		System.out.println("Child class");
	}
}
public class Test1 {

	public static void main(String[] args) {
	B a=new B();
	a.yes();
	A b=new B();
	b.yes();
	A c=new A();
	c.yes();
	
	

	}

}
