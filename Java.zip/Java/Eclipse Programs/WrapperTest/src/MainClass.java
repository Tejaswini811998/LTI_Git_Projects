
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=10;
		Integer num=i;
		System.out.println(num);
		
		i=num;
		System.out.println(i);
		
		char ch='s';
		Character ch1=new Character(ch);
		System.out.println(ch1);
	}

}
