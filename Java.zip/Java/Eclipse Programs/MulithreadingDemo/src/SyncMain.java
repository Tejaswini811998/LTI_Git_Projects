
public class SyncMain {

	public static void main(String[] args) {
		BankAccount bACC =new BankAccount();
		
		new Thread(){
			@Override
			public void run()
			{
				bACC.withdraw(15000);
			}
		}.start();
		
		
		new Thread(){
			@Override
			public void run()
			{
				bACC.deposit(8000);
			}
		}.start();
		
		
		

	}

}
