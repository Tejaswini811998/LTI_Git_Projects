
public class MyThread4 extends Thread {

}
