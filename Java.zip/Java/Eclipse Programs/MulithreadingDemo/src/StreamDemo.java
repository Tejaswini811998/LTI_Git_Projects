import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		

		/*List<String> countries = new ArrayList<String>();
		countries.add("India");
		countries.add("U.S.A");
		countries.add("England");
		countries.add("Mexico");
		
		countries.forEach(c->{
			System.out.println(c);
		});
		
		
		
		List<Integer> nums = new ArrayList<Integer>();
		nums.add(20);
		nums.add(30);
		nums.add(50);
		nums.add(70);
		nums.add(80);
		nums.add(90);
		
		Iterator<Integer> items=nums.iterator();
		while(items.hasNext()){
			System.out.println(items.next());
		}*/
		
		Employee emp1 = new Employee("100AS3", "John", 25, 20000) ;
		Employee emp2 = new Employee("123AS3", "Jack", 35, 250000) ;
		Employee emp3 = new Employee("234AS3", "Joey", 29, 80000) ;
		Employee emp4 = new Employee("678AS3", "Louis",58, 560000) ;
		Employee emp5 = new Employee("788AS3", "Rena", 28, 60000) ;

		
		List<Employee> list=new ArrayList<>();
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		list.add(emp5);
		
		Stream<Employee> emp_data=list.stream();//.filter(e->e.getSalary()>30000);
		
		emp_data.forEach(e->
		System.out.println(e.getEmployeeName())
		);
	}

}
