class Thread1 extends Thread{
	public void run(){
		for (int i = 1; i <=50; i++) {
			System.out.println(Thread.currentThread().getName()+": "+i );
			
		}
	}
}
public class ThreadDemo1 {

	public static void main(String[] args) {
		
		Thread th=Thread.currentThread();
		System.out.println(th.getName()+" started");
		
		Thread1 t1=new Thread1();
		t1.setName("Thread 1");
		Thread1 t2=new Thread1();
		t2.setName("Thread 2");
		Thread1 t3=new Thread1();
		t3.setName("Thread 3");
		
		t1.setPriority(Thread.MAX_PRIORITY);
		t2.setPriority(Thread.NORM_PRIORITY+2);
		t3.setPriority(Thread.MIN_PRIORITY);
		
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		System.out.println(t3.getPriority());
		System.out.println(Thread.currentThread().getPriority());
		t1.start();
		t2.start();
		t3.start();
		System.out.println(th.getName()+" ended");
	}

}
