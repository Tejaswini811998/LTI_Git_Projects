
public class BankAccount {
	
	double balance=10000;
	public synchronized void withdraw(double amt)
	{ if(balance<amt){
		System.out.println("insufficient Balance");
		try{
		this.wait();
	}
		catch(InterruptedException e){
			e.printStackTrace();
		}
	}
	 balance=balance-amt;
	 System.out.println("Available balance is:"+balance);
	}
	
	public synchronized void deposit(double amt)
	{
		System.out.println("Depositing Amount");
	 balance=balance+amt;
	 System.out.println("Amount Deposited");
	 this.notify();
	}
}
