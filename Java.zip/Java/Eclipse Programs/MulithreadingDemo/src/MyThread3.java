
public class MyThread3 implements Runnable {

	@Override
	public void run() {
		for(int i=1000;i<=1050;i++)
		{
			System.out.println(Thread.currentThread().getName()+":"+i);
		}
		System.out.println("Is t3 alive "+Thread.currentThread().isAlive());
	}

}
