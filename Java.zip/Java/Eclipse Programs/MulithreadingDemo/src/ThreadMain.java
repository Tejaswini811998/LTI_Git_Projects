
public class ThreadMain {

	public static void main(String[] args) {
	
		/*
		Thread t1=new Thread(new MyThread2(),"thread1");
		//Thread t3=new Thread(new MyThread3(),"thread3");
		Thread t2=new Thread(new MyThread4(),"thread4");
		t1.start();
		t2.start();
		//t3.start();
		//new Thread(new MyThread2(),"t1").start()
*/	
		System.out.println("Main Thread Starting : "+Thread.currentThread().getName());
		
		Thread t1=new Thread(new MyThread2(),"thread1");
		Thread t2=new Thread(new MyThread3(),"thread2");
		Thread t3=new Thread(new MyThread1(),"thread3");
		
		t1.start();
		try
		{
			t1.join(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		t2.start();
		t3.start();
		
		/*try{
			t3.join();
		}
		catch(InterruptedException ie){
			ie.printStackTrace();
		}
		t2.start();
		try
		{
			t2.join(1000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		System.out.println("Is t3 alive "+t3.isAlive());*/
		System.out.println("Main Thread Ending : "+Thread.currentThread().getName());
	}

}
