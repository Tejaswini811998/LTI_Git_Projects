
public class StringComp {

	public static void main(String[] args) {
		String s="India";
		String s1="India";
		if(s1==s)
		{
			System.out.print("B");
		}
		else
		{
			System.out.print("A");
		}
	}

}
