import java.util.Scanner;

public class StringMain {

	public static void main(String[] args) {
		
		
		/*String str="Larsen & Toubro";
		System.out.println("String value:"+str);
		
        char ch=str.charAt(5);
        System.out.println(ch);
        
        System.out.println(str.length());
        
        char []chStr=str.toCharArray();
	
       // str=str +"Infotech";
        
        str=str.concat(" Infotech");
        System.out.println(str);
        
		
		String name= "India";
		String nm = new String("India");
		String nm1 = new String("India");
		
		System.out.println(name.equals(nm));
		System.out.println(name==nm);
		
		System.out.println(nm.equals(nm1));
		System.out.println(nm1==nm);
		
		String name1="India";
		
		System.out.println(name.equals(name1));
		System.out.println(name==name1);*/
		Scanner sc = new Scanner(System.in);
		String[] names=new String[5];
		System.out.println("Enter 5 strings");
		int i=0;
		for(String nm:names)
		{
			
			names[i] = sc.nextLine();
			i++;
		}
		
		/*for(int i=0;i<5;i++)
		{
			System.out.println("String: "+names[i]+"\n"+ names[i].length());
		}*/
		
		for(String nm:names)
		{
			System.out.println(nm);
		}
		
	}

}
