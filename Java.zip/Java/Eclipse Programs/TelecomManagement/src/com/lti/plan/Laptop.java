package com.lti.plan;

public class Laptop {

	String cpu;
	HardDisk disk;
	
	
	public Laptop(HardDisk disk) {
		
	}
	
	
}
