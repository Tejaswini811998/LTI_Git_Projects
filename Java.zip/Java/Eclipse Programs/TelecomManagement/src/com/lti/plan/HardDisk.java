package com.lti.plan;

public class HardDisk {

}
