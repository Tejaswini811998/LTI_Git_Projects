package com.lti.plan;

abstract class TelecomPlan {
	abstract void calling();
	protected void data()
	{
		
	}
}
