package com.lti.plan;

public class ConsumerPlan extends TelecomPlan {

	@Override
	void calling() {
	System.out.println("Consumer class calling");
		
	}

}
