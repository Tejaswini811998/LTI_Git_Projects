package com.lti.plan;

public class CorporatePlan extends TelecomPlan {

	@Override
	void calling() {
		System.out.println("Corporate Calling Plan");
	}

	
}
