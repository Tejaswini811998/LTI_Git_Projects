package com.lti.plan;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		//TelecomPlan plan = new ConsumerPlan();
		//TelecomPlan plan= new CorporatePlan();
		
		System.out.println("1.Consumer plan: "+"    " +"2.Corporate  Plan: ");
		int ch = new Scanner(System.in).nextInt();
		TelecomPlan plan=null;
		if(ch==1){
			plan = new ConsumerPlan();
		}
		
		else if(ch==2){
			plan = new CorporatePlan();
		}
		plan.calling();
   }

}
