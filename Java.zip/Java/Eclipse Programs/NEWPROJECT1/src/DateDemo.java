import java.time.LocalDate;
import java.time.LocalDateTime;

public class DateDemo {

	public static void main(String[] args) {
	LocalDate today=  LocalDate.now();
	System.out.println("Today's Date : "+today);
	
	LocalDateTime dt1=LocalDateTime.now();
	System.out.println("\nToday's Date and Current Time is:"+dt1);
	
	}

}
