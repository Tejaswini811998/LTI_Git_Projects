import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.lang.*;

import javax.swing.text.DateFormatter;

public class DateFormat {

	public static void main(String[] args) {
		/*LocalDate today = LocalDate.now();
//		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
//		System.out.println(formatter.format(today));
	   DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	   String d=dtf.format(today);
	   System.out.println(d);
	   */
		/*byte  []b={65,66,67};
	   String s = new String(b);
	   System.out.println(s);
	   
	   String s1="HELLOWORLD";
	   System.out.println(s1.charAt(5));
	   
	   String s2="helloworld";
	   String s3=s2.toUpperCase();*/
	 
	 double a=36.0;
	System.out.println(Math.PI);
	System.out.println(Math.sqrt(a));
	}

}
