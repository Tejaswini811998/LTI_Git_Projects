package com.lti;

public class Manager extends Employee {

	String mprojectName;
	int mprojectDuration;
	
	public Manager() {
		super();
	}
	
	public Manager(String psNo, String employeeName, int employeeAge, double salary,String mpName,int mpDur) {
		super(psNo, employeeName, employeeAge, salary);
		mprojectName=mpName;
		mprojectDuration=mpDur;
		
		
	}

	public Manager(String psNo, String employeeName, int employeeAge,String mpName) {
		super(psNo, employeeName, employeeAge);
		mprojectName=mpName;
		//mprojectDuration=mpDur;
	}

	public String getMprojectName() {
		return mprojectName;
	}

	public void setMprojectName(String mprojectName) {
		this.mprojectName = mprojectName;
	}

	public int getMprojectDuration() {
		return mprojectDuration;
	}

	public void setMprojectDuration(int mprojectDuration) {
		this.mprojectDuration = mprojectDuration;
	}

	public void DisplayManager(){
		super.displayEmployee();
		System.out.println("Project Name: "+mprojectName);
		System.out.println("Project Duration:"+mprojectDuration);
		}
	
}
