package com.lti;

public class Trainer extends Employee {

	private String trainingDomain;
	private int trainingDuration;
	
	public Trainer() {
		super();
	}

	public Trainer(String psNo, String employeeName, int employeeAge, double salary,String trnDomain,int trnDur) {
		super(psNo, employeeName, employeeAge, salary);
		trainingDomain=trnDomain;
		trainingDuration=trnDur;
	}


	public Trainer(String psNo, String employeeName, int employeeAge,String trnDomain,int trnDur) {
		super(psNo, employeeName, employeeAge);
		trainingDomain=trnDomain;
		trainingDuration=trnDur;
	}


	/*public String getTrainingDomain() {
		return trainingDomain;
	}


	public void setTrainingDomain(String trainingDomain) {
		this.trainingDomain = trainingDomain;
	}


	public int getTrainingDuration() {
		return trainingDuration;
	}


	public void setTrainingDuration(int trainingDuration) {
		this.trainingDuration = trainingDuration;
	}*/
	public void DisplayTrainer(){
	super.displayEmployee();
	System.out.println("Domain: "+trainingDomain);
	System.out.println("Duration:"+trainingDuration);
	
	}
	
}
