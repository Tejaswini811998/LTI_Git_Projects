// HIERARCHICAL INHERITANCE EXAMPLE------------------------------------------


package com.lti;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
	
		//Employee emp=new Employee();
		
		Scanner sc = new Scanner(System.in);
		/*
		System.out.println("Add an Employee");
		System.out.println("Update an Employee");
		System.out.println("Delete an Employee");
		System.out.println("Search an Employee");
		System.out.println("Display All Employee");
		
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		
		switch(ch)
		{
			case 1:
		}*/
		
		/*Employee emp1=new Employee();
		emp1.setPsNo("1001");
		emp1.setEmployeeName("John");
		emp1.setEmployeeAge(22);
		emp1.setSalary(20000);
		
		Employee emp2=new Employee("1002", "Mark", 23);
		emp2.setSalary(25000);
		
		Employee emp3=new Employee("1003", "James", 22, 23000);
		
		System.out.println("PS No: "+emp1.getPsNo());
		System.out.println("Employee Name: "+emp1.getEmployeeName());
		System.out.println("Age: "+emp1.getEmployeeAge());
		System.out.println("Salary: "+emp1.getSalary());
		
		System.out.println("PS No: "+emp2.getPsNo());
		System.out.println("Employee Name: "+emp2.getEmployeeName());
		System.out.println("Age: "+emp2.getEmployeeAge());
		System.out.println("Salary: "+emp2.getSalary());*/
		
		/*Employee []emp=new Employee[5];
		
		for(int i=0;i<5;i++)
		{
			//emp[i]=new Employee();
			System.out.println("Enter PS No, Name, Age, Salary:");
			String pno=sc.next();
			String nm=sc.next();
			int ag=sc.nextInt();
			double sal=sc.nextDouble();
			System.out.println("Enter your designation");
			String desig=sc.next();
			if(desig.equals("Manager")){
				emp[i]=new Manager();
			}
			else if(desig.equals("Trainer")){
				emp[i]=new Trainer();
			}
			else{
				emp[i]=new Employee();
			
			}
			emp[i].setPsNo(pno);
			emp[i].setEmployeeName(nm);
			emp[i].setEmployeeAge(ag);
			emp[i].setSalary(sal);
		}
		System.out.println("PS No.  Name   Age   Salary");
		for(Employee e:emp)
		{
			System.out.println(e.getPsNo()+"   "+e.getEmployeeName()+"   "+e.getEmployeeAge()+"   "+e.getSalary());
			
		}*/
		
		Trainer trainer1=new Trainer("1111","Jenny",24,60000,"Java",2);
		trainer1.DisplayTrainer();
		
		Manager manager1=new Manager("1112","Andrew",35,80000,"CitiBank",3);
		 manager1.DisplayManager();
	}

}
