//EXCEPTION HANDLING DEMO----------------------------------------------

import java.io.*;
import java.util.Scanner;
public class ExceptionMain {

	public static void main(String[] args)throws FileNotFoundException {
		
		/*Scanner sc=new Scanner(System.in);
		int  num1,num2,res=0,pos=-1;
		
		int age=0;
		System.out.println("Enter your age");
		age = sc.nextInt();
		
		if(age<18)
		{
			try{
			throw new AgeException("Age should be greater than 18");
			}catch(AgeException ae)
			{
				System.out.println(ae.getMessage());
			}
		}
		System.out.println("Enter two numbers:");
		num1=sc.nextInt();
		num2=sc.nextInt();
		try{
			res=num1/num2;
		}
		catch(ArithmeticException ae){
			System.out.println(ae.getMessage());
			System.out.println("Division by zero not possible");
		}
		
		System.out.println("Quotient:"+res);
		int []arr={10,20,30,40};
		
		System.out.println("Enter the position:");
		pos=sc.nextInt();
		try{
			System.out.println(arr[pos]);
		}
		catch(ArrayIndexOutOfBoundsException ar){
			System.out.println("Invalid postion");
			
		}
		
		
		
		Employee emp=null;
		try{
			System.out.println(emp.getEmployeeName());
		}
		catch(NullPointerException ne){
			System.out.println("Object is not intialized");
		}
		
		System.out.println("End Of the Program");
		
		
	}*/
		int x = 5, y = 10;
	 boolean b = x < 0;
	 if(b = true) {
	System.out.print(x);
	 } else {
		 System.out.print(y);
		 }
	}
}
