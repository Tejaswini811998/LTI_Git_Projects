//EXCEPTION HANDLING DEMO 2----------------------------------------------

import java.io.FileNotFoundException;
import java.util.Scanner;
public class ExceptionMain2 {

	public static void main(String[] args)throws FileNotFoundException {
		
		Scanner sc=new Scanner(System.in);
		int  num1,num2,res=-1,pos=-1;
		System.out.println("Enter two numbers:");
		num1=sc.nextInt();
		num2=sc.nextInt();
		Employee emp;
		try{
			res=num1/num2;
			
			int []arr={10,20,30,40};
			System.out.println("Enter the position:");
			pos=sc.nextInt();
			System.out.println(arr[pos]);
			emp=new Employee();
			emp.setEmployeeName("John");
			System.out.println(emp.getEmployeeName());
			throw new NumberFormatException();
		}
		catch(ArithmeticException ae){
			System.out.println(ae.getMessage());
			System.out.println("Division by zero not possible");
		}
		
		
		
		catch(ArrayIndexOutOfBoundsException ar){
			System.out.println("Invalid postion");
			
		}
		
		catch(NullPointerException ne){
			System.out.println("Object is not intialized");
		}
		
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		finally{
		System.out.println("Quotient:"+res);
		}
		System.out.println("End Of the Program");
		
		
	}

}
