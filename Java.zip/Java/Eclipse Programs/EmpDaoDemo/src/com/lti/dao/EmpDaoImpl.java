package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.model.Employee;
public class EmpDaoImpl implements EmpDao {

	final String URL="jdbc:oracle:thin:@localhost:1521:XE";//final so that user cannot change values....
	final String user="hr";
	final String pass="hr";
	Connection conn=null;
	int i;
	String sql;
	Statement st;
	
	public EmpDaoImpl() throws SQLException {
		conn=DriverManager.getConnection(URL, user, pass);
		if(conn!=null){
			System.out.println("\nCONNECTION ESTABLISHED...............................");
		}
	}

	@Override
	public int addAnEmployee(Employee emp) {
			
		sql="insert into emp(psno,name,salary,designation) values(SEQ_ID5.nextval,?,?,?)";
		try{
			
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, emp.getName());
			ps.setDouble(2, emp.getSalary());
			ps.setString(3, emp.getDesignation());
			i=ps.executeUpdate();
		}
	    catch(SQLException e){
				e.printStackTrace();
			}
		return i;
	}

	@Override
	public void updateAnEmployee(Employee emp,int p) {
		sql="Update emp set name =?,salary=?,designation =? where psno="+p;
		try{
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,emp.getName());
		ps.setDouble(2,emp.getSalary());
		ps.setString(3,emp.getDesignation());
		
		i=ps.executeUpdate();
		if(i>0)
			System.out.println("EMPLOYEE RECORD UPDATED!!!!!");
		
			else
				System.out.println("Employee could not be UPDATED");
		
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	@Override
	public int deleteAnEmployee(int psno) {
	sql="delete emp where psno=?";
	try{
		
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setInt(1, psno);
		i=ps.executeUpdate();
		
	}
    catch(SQLException e){
			e.printStackTrace();
		}
	return i;
	}

	@Override
	public Employee searchAnEmployee(int psno) {
		  Employee e = new Employee();
		try{
			st=conn.createStatement();
		    ResultSet rs=st.executeQuery("select * from emp where psno="+psno);
		  while(rs.next()){
			e.setPsno(rs.getInt(1));
			e.setName(rs.getString(2));
			e.setSalary(rs.getDouble(3));
			e.setDesignation(rs.getString(4));
			
		  }

		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		
	System.out.println("EMPLOYEE FOUND!!!!!");
	return e;

	}

	@Override
	public List<Employee> viewAllEmployees() {
		
		
		List<Employee> employee=new ArrayList<Employee>();
		//sql="select * from emp";
		try{
			st=conn.createStatement();
		ResultSet rs=st.executeQuery("select * from emp");
		
		
		while(rs.next()){
			Employee e=new Employee();
			e.setPsno(rs.getInt(1)); //TAKING FROM RESULT SET ADD IT INTO E 
			e.setName(rs.getString(2));
			e.setSalary(rs.getDouble(3));
			e.setDesignation(rs.getString(4));
			
			employee.add(e);
		}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		System.out.println(" VIEW ALL EMPLOYEES!!!!!");
		
		return employee;
	}

}
