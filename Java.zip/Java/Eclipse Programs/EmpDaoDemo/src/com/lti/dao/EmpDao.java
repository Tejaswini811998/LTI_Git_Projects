package com.lti.dao;
import java.util.List;

import com.lti.model.Employee;
public interface EmpDao {
	
	int addAnEmployee(Employee emp);
	void updateAnEmployee(Employee emp,int psno);
	int deleteAnEmployee(int psno);
	Employee searchAnEmployee(int psno);   //should return object after fetching from employee
	List<Employee> viewAllEmployees();
}
