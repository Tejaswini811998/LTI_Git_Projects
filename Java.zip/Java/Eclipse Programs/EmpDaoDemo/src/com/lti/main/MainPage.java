

package com.lti.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.lti.dao.EmpDao;
import com.lti.dao.EmpDaoImpl;
import com.lti.model.Employee;

public class MainPage {

	final static String URL="jdbc:oracle:thin:@localhost:1521:XE";
	final static String user="hr";
	final static String pass="hr";
	public static void main(String[] args) throws SQLException {
		

		Statement st;
		Connection conn=null;
		
		
		
		System.out.println();
		System.out.println("\n***********************WELCOME TO EMPLOYEE MANAGEMENT PORTAL*********************\n\n\n");
	
		System.out.println("\n----PLEASE SELECT AN OPERATION--------\n\n");
		System.out.println("1. ADD AN EMPLOYEE-->\n");
		System.out.println("2. UPDATE AN EMPLOYEE-->\n");
		System.out.println("3. DELETE AN EMPLOYEE-->\n");
		System.out.println("4. SEARCH AN EMPLOYEE-->\n");;
		System.out.println("5. VIEW ALL EMPLOYEE-->\n");
		System.out.println("6. EXIT-->\n");
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("\nENTER YOUR CHOICE:------");
		int ch=sc.nextInt();
		EmpDao dao=new EmpDaoImpl();
		List<Employee> li = new ArrayList<>();
		int res;
		Employee emp = new Employee();
		
		switch(ch){
			case 1:
				System.out.println("Enter name,salary and designation:");
				
				emp.setName(sc.next());
				emp.setSalary(sc.nextDouble());
				emp.setDesignation(sc.next());
				
				res = dao.addAnEmployee(emp);
				if(res>0)
					System.out.println("EMPLOYEE ADDED!!!!!");
					else
						System.out.println("Employee could not be Added");
				break;
				
			case 2:
				System.out.println("Enter psno for updating");
				int psno=sc.nextInt();
				System.out.println("Enter name,salary,designation");
				emp.setName(sc.next());
				emp.setSalary(sc.nextDouble());
				emp.setDesignation(sc.next());
				dao.updateAnEmployee(emp,psno); 
				
				break;
				
			case 3:
					System.out.println("Enter Employee PSNO for deletion:");
					int psno1=sc.nextInt();
	
					int r=dao.deleteAnEmployee(psno1);
					if(r>0)
						System.out.println("EMPLOYEE RECORD DELETED!!!!!");
					
						else
							System.out.println("Employee could not be Deleted");
					
					break;
				
			case 4:
					System.out.println("Enter psno");
					psno = sc.nextInt();
					Employee e = dao.searchAnEmployee(psno);
					if(e!=null)
						System.out.println("Employee Record Found");
					System.out.println(e.getPsno()+" "+e.getName()+" "+e.getSalary()+" "+e.getDesignation());
				
				break;
				
			case 5:
				li = dao.viewAllEmployees();
				Iterator<Employee> itr2=li.iterator();
				while(itr2.hasNext()){
					
					Employee e1 = itr2.next();
					System.out.println(e1.getPsno()+"   "+e1.getName()+"   "+e1.getSalary()+"   "+e1.getDesignation());
				}
				break;
				
			default:
				break;
			
		
		
		}
		
	}

}
