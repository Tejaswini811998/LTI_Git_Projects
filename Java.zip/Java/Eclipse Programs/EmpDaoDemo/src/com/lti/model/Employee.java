package com.lti.model;

public class Employee {
	private int psno;
	private String name;
	private double salary;
	private String designation;
	
	public Employee() {
		super();
	}
	
	public Employee(int psno, String name, double salary, String designation) {
		super();
		this.psno = psno;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
	}
	
	public int getPsno() {
		return psno;
	}
	public void setPsno(int psno) {
		this.psno = psno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
}
