import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;

public class DateMain {

	public static void main(String[] args) {
		
		LocalDate date = LocalDate.now();
		System.out.println("Today is: "+date);
		
		 LocalDate birthDate=LocalDate.of(2019, 02, 28);
		 System.out.println("Birth Date is:"+birthDate);
		 
		 LocalDate todayUS=LocalDate.now(ZoneId.of("America/Los_Angeles"));
		 System.out.println(todayUS);
		
		 LocalTime time = LocalTime.now();
			System.out.println("Today is: "+time);
			
		 LocalTime todayUS1=LocalTime.now(ZoneId.of("America/Los_Angeles"));
		 System.out.println(todayUS1);
		 
		 LocalTime time1=LocalTime.of(16, 25,20);
		 System.out.println(time1);
		 
		 LocalTime time2=LocalTime.of(23, 25,20);
		 System.out.println(time1);
		 
		 LocalDateTime dateTime=LocalDateTime.now();
		 System.out.println(dateTime);
		 
		 
		 
		 
	}

}
