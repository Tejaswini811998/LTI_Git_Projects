
class AddCalculator
{
	public int area(int a,int b)
	{
		return a+b;
	}
	
	public int area(int a,int b,int c)
	{
		return a+b+c;
	}
	
	public int area(int a)
	{
		return a;
	}
	public float area(int a,float b)
	{
		return a+b;
		
	}
	@Deprecated
	public String area(String a, String b)
	{
		return a+b;
	}
}
public class AnnotationDemo {

	
	public static void main(String[] args) {
		
		AddCalculator a1=new AddCalculator();
		System.out.println(a1.area(20,30, 40));

	}

}
