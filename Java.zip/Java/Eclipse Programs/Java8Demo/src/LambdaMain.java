
@FunctionalInterface
interface HelloInterface{
void hello();	

}
/*//@FunctionalInterface
interface CalculateInterface{
void operation(int n1,int n2);	

}*/


//@FunctionalInterface
interface CalculateInterface{
int operation(int n1,int n2);	

}

/*class HelloInterfaceClass implements HelloInterface{

	@Override
	public void hello() {
		System.out.println("Hello World");
		
	}
	*/
//}

public class LambdaMain {

	public static void main(String[] args) {
		
//		HelloInterface obj=new HelloInterfaceClass();
//		obj.hello();

	/*	HelloInterface obj=new HelloInterface(){
			@Override
			public void hello(){
				System.out.println("Hello People !!");
			}
		};
		obj.hello();*/
	/*	HelloInterface obj=()->{
			System.out.println("Hello world!!");
		};
		obj.hello();
		
		CalculateInterface a1=(a,b)->
		{
			System.out.println(a+b);
		};
		a1.operation(20,30);
		
		CalculateInterface a2=(a,b)->
		{
			System.out.println(a-b);
		};
		a2.operation(20,30);*/
		
		CalculateInterface ad1=(a,b)->((a+b)-(a*b));
				{
			System.out.println(ad1.operation(30, 10));
		}
		
		
	}

}
