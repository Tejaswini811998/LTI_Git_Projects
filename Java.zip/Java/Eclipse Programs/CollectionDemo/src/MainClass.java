import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class MainClass {

	public static void main(String[] args) {
		
		/*List<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(new Integer(200));
		
		Integer i=new Integer(300);
		
		list.add(i);*/
		
		/*for(Integer val: list)
		{
			System.out.println(val);
		}
		
		List<String> countries = new ArrayList<String>();
		countries.add("India");
		countries.add("Australia");
		countries.add("England");
		countries.add("Mexico");
		
		Iterator<String> items=countries.iterator();
		while(items.hasNext()){
			System.out.println(items.next());
		}
		*/
		Employee emp1 = new Employee("100AS3", "John", 25, 50000) ;
		Employee emp2 = new Employee("123AS3", "Jack", 35, 250000) ;
		Employee emp3 = new Employee("234AS3", "Joey", 29, 80000) ;
		Employee emp4 = new Employee("678AS3", "Louis",58, 560000) ;
		Employee emp5 = new Employee("788AS3", "Rena", 28, 60000) ;

		
		List<Employee> list=new ArrayList<>();
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		list.add(emp5);
		list.add(3,new Employee("452AS3", "Raut", 22, 57000));
	
		/*Iterator itr2=list.iterator();
		while(itr2.hasNext()){
			
			Employee e = (Employee)itr2.next();
			System.out.println(e.getPsNo()+""+e.getEmployeeName()+" "+e.getEmployeeAge()+" "+e.getSalary());
		}
		//System.out.println(list);
		
		Iterator<Employee> itr2=list.iterator();
		while(itr2.hasNext()){
			
			Employee e = itr2.next();
			System.out.println(e.getPsNo()+" "+e.getEmployeeName()+" "+e.getEmployeeAge()+" "+e.getSalary());
		}
		*/
		//Employee emp=list.get(2);
		//System.out.println(emp);
		
	/*	Employee emp6=list.remove(3);
		System.out.println(emp6);*/
		

		Collections.sort(list,new SortBySal());
		//System.out.println("Remaining objects");
		Iterator<Employee> itr2=list.iterator();
		while(itr2.hasNext()){
			
			Employee e = itr2.next();
			System.out.println(e.getPsNo()+" "+e.getEmployeeName()+" "+e.getEmployeeAge()+" "+e.getSalary());
		}
		
		
	}

}
