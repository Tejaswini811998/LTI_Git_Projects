
import java.util.*;

public class HashMain {

	public static void main(String[] args) {
		//Set<Employee> emps = new HashSet<Employee>();
		//Set<Employee> emps = new TreeSet<Employee>();
		HashSet<Employee> emps = new LinkedHashSet<Employee>();
		Employee emp1 = new Employee("100AS3", "John", 25, 50000) ;
		Employee emp2 = new Employee("123AS3", "Jack", 35, 250000) ;
		Employee emp3 = new Employee("234AS3", "Joey", 29, 80000) ;
		Employee emp4 = new Employee("678AS3", "Louis",58, 560000) ;
		Employee emp5 = new Employee("788AS3", "Rena", 58, 60000) ;
		
		emps.add(emp1);
		emps.add(emp2);
		emps.add(emp3);
		emps.add(emp4);
		emps.add(emp5);
		
		Iterator<Employee> itr2=emps.iterator();
		while(itr2.hasNext()){
			
			Employee e = itr2.next();
			System.out.println(e.getPsNo()+" "+e.getEmployeeName()+" "+e.getEmployeeAge()+" "+e.getSalary());
		}
		
		//System.out.println(emps);
	}

}
