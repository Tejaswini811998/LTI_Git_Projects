

public class Employee implements Comparable<Employee>
{
	
	 private String psNo;
	 private String employeeName;
     private int employeeAge;
     private double salary;
     
     public Employee(){
    	 
     }
     
     public Employee(String psNo, String employeeName, int employeeAge) {
		//super();
		this.psNo = psNo;
		this.employeeName = employeeName;
		this.employeeAge = employeeAge;
	}

	public Employee(String psNo, String employeeName, int employeeAge, double salary) {
 		this.psNo = psNo;
 		this.employeeName = employeeName;
 		this.employeeAge = employeeAge;
 		this.salary = salary;
 	}

	public String getPsNo() {
		return psNo;
	}

	public void setPsNo(String psNo) {
		this.psNo = psNo;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	 public void addAnEmployee(){
		 Employee emp=new Employee();
		 emp.setPsNo("10665487");
		 emp.setEmployeeName("John");
		 emp.setEmployeeAge(25);
		 
		 
	  }
		
	 public void updateEmployee(){
		  
	  }
		
	 public void removeAnEmployee(){
		  
	 }
	 public void findAnEmployee(){
		  
	 }
	 protected void displayEmployee(){
		 System.out.println("PS No:"+psNo);
		 System.out.println("Name:"+employeeName);
		 System.out.println("Age:"+employeeAge);
		 System.out.println("Salary:"+salary);
	 }

	@Override
	public String toString() {
		return "Employee [psNo=" + psNo + ", employeeName=" + employeeName + ", employeeAge=" + employeeAge
				+ ", salary=" + salary + "]";
	}

	@Override
	public int compareTo(Employee o) {
		/*if(this.employeeAge>o.employeeAge)
		{
			return 1;
		}
		else if(this.employeeAge<o.employeeAge)
		{
			return -1;
		}
		else
			return 0;*/
		return this.getPsNo().compareTo(o.getPsNo());
	}

	

}
