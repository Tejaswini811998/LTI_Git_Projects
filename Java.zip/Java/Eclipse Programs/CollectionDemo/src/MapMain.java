import java.util.*;
public class MapMain {

	public static void main(String[] args) {
	HashMap<String,String> credentials = new HashMap<>();
	
	credentials.put("user1","pass1");
	credentials.put("user3","pass3");
	credentials.put("user4","pass4");
	credentials.put("user5","pass5");
	credentials.put("user2","pass2");
	
	Set cSets = credentials.entrySet();
	
	Iterator items = cSets.iterator();
	
	while(items.hasNext())
	{
		Map.Entry<String, String> entry =(Map.Entry<String, String>)items.next();
		System.out.println(entry.getKey()+" "+entry.getValue());
	}
	
	
	}

}
