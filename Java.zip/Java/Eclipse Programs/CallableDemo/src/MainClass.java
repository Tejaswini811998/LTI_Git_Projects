import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class MainClass {

	
	
	public static void main(String[] args) throws SQLException {
		
		
		final String URL="jdbc:oracle:thin:@localhost:1521:XE";
		final String user="hr";
		final String pass="hr";
		Connection con=null;
		
		con=DriverManager.getConnection(URL,user,pass);
		
		System.out.println("\n***********************WELCOME TO EMPLOYEE MANAGEMENT PORTAL*********************\n\n\n");
		
		System.out.println("\n----PLEASE SELECT AN OPERATION--------\n\n");
		System.out.println("1. ADD AN EMPLOYEE-->\n");
		System.out.println("2. UPDATE AN EMPLOYEE-->\n");
		System.out.println("3. DELETE AN EMPLOYEE-->\n");
		System.out.println("4. SEARCH AN EMPLOYEE-->\n");;
		System.out.println("5. VIEW ALL EMPLOYEE-->\n");
		System.out.println("6. EXIT-->\n");
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("\nENTER YOUR CHOICE:------");
		int ch=sc.nextInt();
		switch(ch)
		{
		        case 1: CallableStatement st = con.prepareCall("{call  Proc1(?,?,?,?)}");
		 
		              st.setString(1, "Sumeet");
		              st.setDouble(2, 60000);
	                  st.setString(3, "CEO");
		              st.registerOutParameter(4, Types.VARCHAR);
		              st.executeUpdate();
		              System.out.println(st.getString(4));
		              break;
		              
		        case 2:
		        	 break;
		        	 
		        case 3:
		        	break;
		        	
		        case 4:
		        	break;
		        case 5:
		        	break;
		        
		        default:
		
		
		
		
		}
		
	}

}
