// HIERARCHICAL AND MULTILEVEL INHERITANCE EXAMPLE-----------------------------------
// CLASS VARIABLES AND INSTANCE VARIABLES-------------------------------

package loan;

import java.time.LocalDate;

public class MainClass {

	public static void main(String[] args) {
		
		/*HomeLoan hl = new HomeLoan(19798,3,500000,7.98,"House","Plot","Bhiwandi");
		EducationLoan el = new EducationLoan(78945,2,100000,5.32,"Education","B.E",4);
		//VehicleLoan vl = new VehicleLoan(74125,4,85000,8.35,"Vehicle","12456","Access125");
		
		TwoWheelerClass tw1=new TwoWheelerClass(1073, 5, 100000, 5.23, "Vehicle", "45AG65", "ACCESS125", 10);
		ThreeWheelerClass tw2=new ThreeWheelerClass(1587, 3, 500000, 7.45, "Vehicle", "ASD456", "Auto-Rickshaw", true);
		FourWheelerClass tw31=new FourWheelerClass(1256, 7, 200000, 8.13, "Vehicle", "ABC785", "HYUNDAI", 800000);
		
		hl.displayHomeLoanDetails();
		System.out.println("---------------------------------------");
		el.displayEducationLoanDetails();
		System.out.println("---------------------------------------");
		System.out.println("***********VEHICLE LOAN*********");
		System.out.println();
		tw1.displayTwoWheelerDetails();
		System.out.println();
		tw2.displayThreeWheelerDetails();
		System.out.println();
		tw31.displayFourWheelerDetails();
		System.out.println();
		*/
		
		Order ord1=new Order();
		ord1.setOrderDate(LocalDate.now());
		ord1.setTotalItems(5);
		ord1.setTotalPrice(5000);
		
		Order ord2=new Order();
		ord2.setOrderDate(LocalDate.now());
		ord2.setTotalItems(10);
		ord2.setTotalPrice(2000);
		
		Order ord3=new Order();
		ord3.setOrderDate(LocalDate.now());
		ord3.setTotalItems(7);
		ord3.setTotalPrice(2500);
		
		System.out.println(ord1.getOrderId()+"  "+ord1.getTotalPrice()+"   "+Order.shopName);
		System.out.println(ord2.getOrderId()+"  "+ord2.getTotalPrice()+"   " +Order.shopName);
		System.out.println(ord3.getOrderId()+"  "+ord3.getTotalPrice()+"   " +Order.shopName);
		

		System.out.println(Order.shopName);
	
		
	}

}
