package loan;

import java.time.LocalDate;

public class Order {

	private int orderId;
	private LocalDate orderDate;
	private int totalItems;
	private double totalPrice;
	private static int oid=1000;
	public static final String shopName;
	
	static
	{
		shopName="ABC $ Sons";
	}
	public Order()
	{
		this.orderId=++oid;
	}
	
	public Order(int orderId, LocalDate orderDate, int totalItems, double totalPrice) {
		this.orderId=++oid;
		this.orderDate = orderDate;
		this.totalItems = totalItems;
		this.totalPrice = totalPrice;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public int getTotalItems() {
		return totalItems;
	}

	public void setTotalItems(int totalItems) {
		this.totalItems = totalItems;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
}
