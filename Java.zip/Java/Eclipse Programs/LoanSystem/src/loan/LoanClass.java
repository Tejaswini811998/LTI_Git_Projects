

package loan;

public class LoanClass {

	 private int loanNo;
	 private int loanDuration;
	 private int loanAmount;
	 private double loanInterest;
	private String loanType;
	
	protected LoanClass(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType) {
		super();
		this.loanNo = loanNo;
		this.loanDuration = loanDuration;
		this.loanAmount = loanAmount;
		this.loanInterest = loanInterest;
		this.loanType = loanType;
	}
	public int getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(int loanNo) {
		this.loanNo = loanNo;
	}
	public int getLoanDuration() {
		return loanDuration;
	}
	public void setLoanDuration(int loanDuration) {
		this.loanDuration = loanDuration;
	}
	public int getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(int loanAmount) {
		this.loanAmount = loanAmount;
	}
	public double getLoanInterest() {
		return loanInterest;
	}
	public void setLoanInterest(double loanInterest) {
		this.loanInterest = loanInterest;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	
	public LoanClass() {
		super();
	}
	
	protected void displayLoanDetails(){
		//System.out.println("---------------------------------------");
		System.out.println("Loan No:"+loanNo);
		System.out.println("Loan Duration:"+loanDuration);
		System.out.println("Loan Amount:"+loanAmount);
		System.out.println("Loan Interest:"+loanInterest);
		System.out.println("Loan Type:"+loanType);
	}
	
}
