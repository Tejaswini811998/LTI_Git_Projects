package loan;

public class EducationLoan extends LoanClass {

	private String courseName;
	private int courseDuration;
	
	public EducationLoan(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType,
			String courseName, int courseDuration) {
		super(loanNo, loanDuration, loanAmount, loanInterest, loanType);
		this.courseName = courseName;
		this.courseDuration = courseDuration;
	}

	public EducationLoan() {
		// TODO Auto-generated constructor stub
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(int courseDuration) {
		this.courseDuration = courseDuration;
	}
	void displayEducationLoanDetails()
	{
		super.displayLoanDetails();
		System.out.println("Course Name:"+courseName);
		System.out.println("Course Duration:"+courseDuration);
	}
	
	
}
