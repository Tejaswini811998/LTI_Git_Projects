package loan;

public class ThreeWheelerClass extends VehicleLoan {

	private boolean approved;

	public ThreeWheelerClass(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType,
			String modelNumber, String vehicleType, boolean approved) {
		super(loanNo, loanDuration, loanAmount, loanInterest, loanType, modelNumber, vehicleType);
		this.approved = approved;
	}

	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	
	protected void displayThreeWheelerDetails(){
		super.displayVehicleLoanDetails();
		System.out.println("Approval for Three Wheeler:"+approved);
	}
	
	
}
