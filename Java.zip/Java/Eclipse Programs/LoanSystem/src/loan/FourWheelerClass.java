package loan;

public class FourWheelerClass extends VehicleLoan {

	private double yearlyIncome;

	public FourWheelerClass(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType,
			String modelNumber, String vehicleType, double yearlyIncome) {
		super(loanNo, loanDuration, loanAmount, loanInterest, loanType, modelNumber, vehicleType);
		this.yearlyIncome = yearlyIncome;
	}

	public double getYearlyIncome() {
		return yearlyIncome;
	}

	public void setYearlyIncome(double yearlyIncome) {
		this.yearlyIncome = yearlyIncome;
	}
	
	protected void displayFourWheelerDetails(){
		super.displayVehicleLoanDetails();
		System.out.println("Yearly Income for Four Wheeler:"+yearlyIncome);
	}
	
}
