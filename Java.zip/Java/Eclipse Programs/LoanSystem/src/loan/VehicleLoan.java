package loan;

public class VehicleLoan extends LoanClass {

	private String modelNumber;
	private String VehicleType;

	public VehicleLoan(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType,
			String modelNumber, String vehicleType) {
		super(loanNo, loanDuration, loanAmount, loanInterest, loanType);
		this.modelNumber = modelNumber;
		VehicleType = vehicleType;

	}

	public VehicleLoan() {
		// TODO Auto-generated constructor stub
	}

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public String getVehicleType() {
		return VehicleType;
	}

	public void setVehicleType(String vehicleType) {
		VehicleType = vehicleType;
	}

	void displayVehicleLoanDetails() {
		super.displayLoanDetails();
		System.out.println("Model Number:" + modelNumber);
		System.out.println("Type of Vehicle:" + VehicleType);

	}
	
	

}
