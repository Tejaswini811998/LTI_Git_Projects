package loan;

public class HomeLoan extends LoanClass {

	private String propertyType;
	 private String location;
	
	public HomeLoan(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType,
			String propertyType, String location) {
		super(loanNo, loanDuration, loanAmount, loanInterest, loanType);
		this.propertyType = propertyType;
		this.location = location;
	}

	public HomeLoan() {
		// TODO Auto-generated constructor stub
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	public void displayHomeLoanDetails(){
		super.displayLoanDetails();
		System.out.println("House Loan Property Type:"+propertyType);
		System.out.println("House Loan Property Location:"+location);
	}
	
	
}
