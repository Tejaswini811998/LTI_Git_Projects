package loan;

public class TwoWheelerClass extends VehicleLoan {

	private int noOfCheques;

	public TwoWheelerClass(int loanNo, int loanDuration, int loanAmount, double loanInterest, String loanType,
			String modelNumber, String vehicleType, int noOfCheques) {
		super(loanNo, loanDuration, loanAmount, loanInterest, loanType, modelNumber, vehicleType);
		this.noOfCheques = noOfCheques;
	}

	public int getNoOfCheques() {
		return noOfCheques;
	}

	public void setNoOfCheques(int noOfCheques) {
		this.noOfCheques = noOfCheques;
	}
	
	protected void displayTwoWheelerDetails(){
		super.displayVehicleLoanDetails();
		System.out.println("No. of Cheques for Two Wheeler:"+noOfCheques);
	}
}
