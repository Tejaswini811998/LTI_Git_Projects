package comp.lti.shape;

public abstract class Shape {

	public abstract void area();
	
 Shape(){
	 
 }
 
}
