package comp.lti.shape;

public class Circle extends Shape {

	int radius;
	
	public Circle(int radius) {
		super();
		this.radius = radius;
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub
     double area;
     area=3.14*radius*radius;
     System.out.println("Area of circle"+area);
	}

  
	public void circumference(){
		double circumference=2*3.14*radius;
		System.out.println("Circumference of circle is:"+circumference);
	}
}
