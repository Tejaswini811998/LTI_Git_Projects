package comp.lti.shape;

import java.util.Scanner;

public class MainShapeClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Shape s1=null;
		Shape s2;
		System.out.println("Enter 1.Circle 2.Square 3.Rectangle");
		int ch=new Scanner(System.in).nextInt();
	    if(ch==1){
	    	s1=new Circle(5);
	    	new Circle(5).circumference();
	    	
	    }
	    else if(ch==2){
	    	s1=new Square(10);
	    }
	    else if(ch==3){
	    	s1=new Rectangle(25,35);
	    }
	    s1.area();
	}

}
