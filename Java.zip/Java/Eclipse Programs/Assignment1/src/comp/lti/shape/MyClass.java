package comp.lti.shape;

public class MyClass 
{ public static void main(String[] args)
{ /*int i=0; 
int j;
for (j=0; j<10; ++j)
{ i++; }
System.out.println(i + " " + j); */
	 int y = 1; 
	 do {
		 System.out.print(y + "");
	  }while(y <= 10); 
} 
} 