package comp.lti.shape;

public class test {
	int che()
	{
		try{
		return 0;
		}
		catch(Exception e)
		{
			return 1;
		}
		finally {
			return 2;
		}
	}
	
	public static void main(String[] args) {
	test t = new test();
    System.out.println(t.che());
	

	}

}
