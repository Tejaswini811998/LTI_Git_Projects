package comp.lti.shape;

public class Square extends Shape {

	
	int side;

	public Square(int side) {
		super();
		this.side = side;
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub
           int area;
            area=side*side;
            System.out.println("Area of square:"+area);
	}

	 public void perimeter(){
			int perimeter=4*side;
			System.out.println("Perimeter of square:"+perimeter);
		}
		
}
