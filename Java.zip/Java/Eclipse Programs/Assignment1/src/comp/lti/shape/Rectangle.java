package comp.lti.shape;

public class Rectangle extends Shape {

	int length,breadth;
	
	public Rectangle(int length, int breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub

		int area=length*breadth;
		System.out.println("Area of Rectangle :"+area);
	}

	 public void perimeter(){
			int perimeter=2*(length+breadth);
			System.out.println("Perimeter of rectangle:"+perimeter);
		}
		
}
