import java.util.Arrays;
import java.util.*;
class SecondMax2
{
 public static void main(String args[])
 {
  int i;
 Scanner sc=new Scanner(System.in);
 int []arr=new int[20];
 System.out.println("Enter number for list:");
 int n=sc.nextInt();
 System.out.println("Enter array numbers:");
 for(i=0;i<n;i++)
 {
  arr[i]=sc.nextInt();
 }
 Arrays.sort(arr,0,n-1);
System.out.println(arr[n-2]);
 }
}