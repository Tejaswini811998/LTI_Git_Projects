import java.util.*;
class Primeno
{
	public static void main(String args[])
	{
		int i,j,n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range of numbers");
		n = sc.nextInt();
		for(i=0;i<=n;i++)
		{
			for(j=2;j<=n;j++)
			{
	   			if(i%j == 0)			
					break;
				
				
  			}
			
			
			
		
		}
	}
}