import java.util.*;
class SecondMax
{
public static void main(String args[])
{
int i,temp;
Scanner sc=new Scanner(System.in);
int []arr=new int[20];
System.out.println("Enter number for list:");
int n=sc.nextInt();
System.out.println("Enter array numbers:");
for(i=0;i<n;i++)
{
arr[i]=sc.nextInt();
}

for(i=0;i<n;i++)
{
for(int j=i+1;j<n;j++){
if(arr[i]>arr[j])
{
temp=arr[i];
arr[i]=arr[j];
arr[j]=temp;
}
}
}
System.out.println("Second Largest Number is:");
System.out.print(arr[n-2]);
}
}