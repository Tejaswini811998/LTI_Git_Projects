import java.util.*;
class ArraySum
{
 public static void main(String args[])
 {
  int[] n = new int[5];
  int sum = 0;
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter 5 numbers :");
  for(int i=0;i<n.length;i++)
   n[i]=sc.nextInt();
  
  System.out.println("Addition of 5 numbers is:");
  for(int i=0;i<n.length;i++)
    sum = sum + n[i];

  System.out.println(sum);
	
 }
}